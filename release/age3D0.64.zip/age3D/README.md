# AppGameKit AGE3D

TheGameCreators are hosting the source code to AGE3D (AppGameKit Game Editor 3D) on behalf of the original author with a view to allowing interested members of the community to collaborate to bring the development forward. This code is licensed under the MIT license.
